=== KKG Music ===
Contributors: Karthigesh
Tags: form, music, upload, url
Requires at least: 6.0
Tested up to: 6.2.2
Stable tag: 5.7.7
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Music upload plugin.

= Privacy notices =

With the default configuration, this plugin, in itself, does not:

* track users by stealth;
* write any user personal data to the database;
* send any data to external servers;
* use cookies.

== Installation ==

1. Upload the entire `kkg_musics` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the **Plugins** screen (**Plugins > Installed Plugins**).

You will find **KKG Music** menu in your WordPress admin screen.
